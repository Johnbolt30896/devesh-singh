import React, { useState, useEffect } from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import { Moon, Sun } from 'lucide-react';
import clsx from 'clsx';

// Lead type
interface Lead {
  name: string;
  phone?: string;
  email?: string;
  instagram?: string;
  followers?: number; // Instagram
  website?: string;   // Google
  pageType?: string;  // Facebook
}

const dummyLeads: Lead[] = [
  {
    name: "FashionHub Delhi",
    phone: "+91-9876543210",
    email: "info@fashionhubdelhi.com",
    instagram: "@fashionhubdelhi"
  },
  {
    name: "ReadyWear Hyderabad",
    phone: "+91-9012345678",
    instagram: "@readywearhyd"
  },
  {
    name: "StyleShop Chennai",
    phone: "+91-9955511223",
    email: "contact@styleshopchennai.com"
  }
];

function generateInstagramHandle(region: string, niche: string, order: number) {
  const base = (region + niche).replace(/[^a-zA-Z]/g, '').toLowerCase();
  return `@${base}${order === 0 ? '' : order}`;
}

function generateGoogleLead(region: string, niche: string, i: number): Lead {
  return {
    name: `${niche} ${region} Retailer ${i + 1}`,
    phone: `+91-8${Math.floor(Math.random() * 900000000) + 100000000}`,
    email: `contact${i + 1}@${niche.replace(/\s+/g, '').toLowerCase()}${region.replace(/\s+/g, '').toLowerCase()}.com`,
    website: `www.${niche.replace(/\s/g, '')}${region.replace(/\s/g, '')}${i+1}.com`.toLowerCase(),
    instagram: undefined
  };
}

function generateFacebookLead(region: string, niche: string, i: number): Lead {
  return {
    name: `${region} FB Fashion ${i + 1}`,
    phone: `+91-7${Math.floor(Math.random() * 900000000) + 100000000}`,
    email: undefined,
    instagram: `@fb.${region.replace(/\s+/g, '').toLowerCase()}${i + 1}`,
    pageType: 'Retailer Page'
  };
}

const TAB_LABELS = [
  { key: 'instagram', label: 'Instagram' },
  { key: 'google', label: 'Google' },
  { key: 'facebook', label: 'Facebook' }
] as const;

type TabKey = typeof TAB_LABELS[number]["key"];

// Theme toggle (dark mode) -- hydration-safe
const useTheme = () => {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    setTheme(prefersDark ? 'dark' : 'light');
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  return { theme, setTheme, mounted };
};

function App() {
  const { theme, setTheme, mounted } = useTheme();
  const [region, setRegion] = useState("");
  const [niche, setNiche] = useState("");
  const [loading, setLoading] = useState(false);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [activeTab, setActiveTab] = useState<TabKey>('instagram');
  const [error, setError] = useState<string | null>(null);

  const handleFindLeads = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      let liveLeads: Lead[] = [];
      if (activeTab === 'google') {
        // --- LIVE GOOGLE PLACES INTEGRATION ---
        const GOOGLE_API_KEY = 'YOUR_GOOGLE_API_KEY';
        const query = encodeURIComponent(`${niche} ${region} garment retailer`);
        const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${query}&key=${GOOGLE_API_KEY}`;
        const resp = await fetch(url);
        const data = await resp.json();
        if (!data.results || data.results.length === 0) throw new Error('No results from Google Places.');
        liveLeads = await Promise.all(
          data.results.slice(0, 5).map(async (biz: any) => {
            // Place Details for phone/website
            const detResp = await fetch(
              `https://maps.googleapis.com/maps/api/place/details/json?place_id=${biz.place_id}&fields=name,formatted_phone_number,website,formatted_address&key=${GOOGLE_API_KEY}`
            );
            const det = await detResp.json();
            const info = det.result;
            return {
              name: info.name || biz.name,
              phone: info.formatted_phone_number || '',
              website: info.website || '',
              address: info.formatted_address || biz.formatted_address,
              instagram: '',
              email: ''
            };
          })
        );
        setLeads(liveLeads);
      } else if (activeTab === 'instagram') {
        // --- LIVE INSTAGRAM GRAPH API (LIMITED TO OWNED BUSINESS ACCOUNTS) ---
        // Replace with your Instagram business account ID and access token:
        // This will only return data for accounts you manage; public search is NOT available.
        const INSTAGRAM_BUSINESS_ACCOUNT_ID = 'YOUR_INSTAGRAM_BUSINESS_ACCOUNT_ID';
        const INSTAGRAM_GRAPH_TOKEN = 'YOUR_INSTAGRAM_GRAPH_TOKEN';
        const resp = await fetch(
          `https://graph.facebook.com/v19.0/${INSTAGRAM_BUSINESS_ACCOUNT_ID}?fields=name,username,followers_count,profile_picture_url&access_token=${INSTAGRAM_GRAPH_TOKEN}`
        );
        const data = await resp.json();
        if (!data.name || !data.username) throw new Error('No Instagram business account data returned.');
        setLeads([
          {
            name: data.name,
            instagram: '@' + data.username,
            followers: data.followers_count,
          }
        ]);
      } else if (activeTab === 'facebook') {
        // --- LIVE FACEBOOK PAGE API (ONLY OWNED PAGES) ---
        // Replace with your user access token:
        const FACEBOOK_USER_TOKEN = 'YOUR_FACEBOOK_USER_TOKEN';
        const resp = await fetch(
          `https://graph.facebook.com/me/accounts?fields=name,access_token&access_token=${FACEBOOK_USER_TOKEN}`
        );
        const data = await resp.json();
        if (!data.data || !data.data.length) throw new Error('No managed Facebook Pages found.');
        const leadPages = await Promise.all(
          data.data.map(async (page: any) => {
            const pageResp = await fetch(`https://graph.facebook.com/${page.id}?fields=name,about,phone,category&access_token=${page.access_token}`);
            const info = await pageResp.json();
            return {
              name: info.name,
              pageType: info.category,
              phone: info.phone || '',
              instagram: '',
              email: ''
            };
          })
        );
        setLeads(leadPages);
      }
      setLoading(false);
    } catch (err: any) {
      setLoading(false);
      setError('Live API failed or is not configured: ' + (err.message || err.toString()));
      // Fallback to demo/simulated data for continued UX
      let simulatedLeads: Lead[] = [];
      if (activeTab === 'instagram') {
        simulatedLeads.push(...dummyLeads.map((l, i) => ({
          ...l,
          instagram: l.instagram || generateInstagramHandle(region, niche, i),
          followers: Math.floor(Math.random()*9000) + 1000
        })));
        for (let i = 0; i < 2; ++i) {
          simulatedLeads.push({
            name: `${niche} ${region} Outlet ${i + 1}`,
            phone: `+91-9${Math.floor(Math.random()*900000000)+100000000}`,
            instagram: generateInstagramHandle(region, niche, i+3),
            followers: Math.floor(Math.random()*9000) + 1000
          });
        }
      } else if (activeTab === 'google') {
        for (let i = 0; i < 5; ++i) {
          simulatedLeads.push(generateGoogleLead(region, niche, i));
        }
      } else if (activeTab === 'facebook') {
        for (let i = 0; i < 5; ++i) {
          simulatedLeads.push(generateFacebookLead(region, niche, i));
        }
      }
      setLeads(simulatedLeads);
    }
  };

  // --- Export utility functions ---
  const exportToCSV = () => {
    if (!leads.length) return;
    const header = ["Name", "Phone", "Email", "Instagram"];
    const rows = leads.map(l => [l.name, l.phone || "", l.email || "", l.instagram || ""]);
    const csvContent = [header, ...rows]
      .map(r => r.map(f => `"${String(f).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, `leads_${activeTab}_${region || "all"}_${niche || "all"}.csv`);
  };

  const exportToExcel = () => {
    if (!leads.length) return;
    const ws = XLSX.utils.json_to_sheet(
      leads.map(l => ({
        Name: l.name,
        Phone: l.phone || "",
        Email: l.email || "",
        Instagram: l.instagram || ""
      }))
    );
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Leads");
    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    const blob = new Blob([wbout], { type: "application/octet-stream" });
    saveAs(blob, `leads_${activeTab}_${region || "all"}_${niche || "all"}.xlsx`);
  };

  function getTabMessage() {
    switch (activeTab) {
      case 'instagram':
        return 'Instagram handle search is simulated for demo purposes. Real integration possible with valid Business API access.';
      case 'google':
        return 'Google Business lead search is simulated for demo, designed for extension with real Google Places or Custom Search API.';
      case 'facebook':
        return 'Facebook business search is simulated for demo. Real results require official API integration.';
      default:
        return '';
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-2 sm:px-4 py-8">
      <div className="rounded-xl shadow-xl bg-white dark:bg-zinc-900 border dark:border-zinc-800 p-4 sm:p-6 md:p-8">
        {/* Branding/Header Area */}
        <div className="flex items-center gap-4 mb-3">
          <img src="https://ugc.same-assets.com/0G_O-xz_mI_UqbVUl2Mq831hWfqfhld-.png" alt="Garment App Logo" className="h-14 w-14 rounded bg-gray-50 dark:bg-zinc-900 p-1 border dark:border-zinc-700" />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold text-zinc-800 dark:text-zinc-200 mb-0">Garment Lead Finder</h1>
              {/* Dark mode toggle: render only after mount (hydration-safe) */}
              {mounted && (
                <button
                  type="button"
                  className="ml-3 p-2 rounded-full border hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  aria-label="Toggle dark mode"
                >
                  {theme === 'dark' ? <Sun className="w-5 h-5 text-yellow-400"/> : <Moon className="w-5 h-5 text-gray-700" />}
                </button>
              )}
            </div>
            <div className="text-zinc-600 dark:text-zinc-300 mt-1 text-base">AI-powered lead prospecting for ready-made garment retailers: find, export, and connect in any region or niche.</div>
          </div>
        </div>
        <form className="flex flex-wrap gap-x-4 gap-y-3 mb-6 items-end" onSubmit={handleFindLeads}>
          <div className="min-w-[160px]">
            <Label htmlFor="region">Region</Label>
            <Input id="region"
              className="rounded-lg border-gray-300 dark:border-zinc-700 focus:ring-2 focus:ring-blue-400 dark:focus:ring-blue-500 shadow-sm"
              value={region}
              onChange={e => setRegion(e.target.value)}
              placeholder="e.g. Delhi, Hyderabad"
              required />
          </div>
          <div className="min-w-[190px]">
            <Label htmlFor="niche">Niche</Label>
            <Input id="niche"
              className="rounded-lg border-gray-300 dark:border-zinc-700 focus:ring-2 focus:ring-blue-400 dark:focus:ring-blue-500 shadow-sm"
              value={niche}
              onChange={e => setNiche(e.target.value)}
              placeholder="e.g. Women's Sportswear"
              required />
          </div>
          <Button type="submit" disabled={loading}
            className="rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 shadow-lg transition focus:ring-2 focus:ring-blue-400 focus:outline-none mt-1">
            {loading ? "Finding..." : "Find Leads"}
          </Button>
        </form>
        <hr className="border-b border-zinc-200 dark:border-zinc-700 mb-4" />
        <div className="mb-4">
          <div className="flex space-x-2 border-b-2 border-zinc-100 dark:border-zinc-800 mb-2 px-1 overflow-x-auto pb-1">
            {TAB_LABELS.map(tab => (
              <button
                key={tab.key}
                className={clsx(
                  "py-2 px-4 font-semibold rounded-t-lg transition-all duration-150 border-b-2",
                  activeTab === tab.key
                    ? "border-blue-500 text-blue-700 bg-blue-50 dark:text-blue-300 dark:bg-zinc-800"
                    : "border-transparent text-gray-500 dark:text-zinc-400 hover:bg-blue-50 dark:hover:bg-zinc-800 hover:text-blue-600"
                )}
                onClick={() => { setActiveTab(tab.key); setLeads([]); }}
                type="button"
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        {leads.length > 0 && (
          <Table className="rounded-xl overflow-hidden">
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Instagram</TableHead>
                {activeTab === 'instagram' && <TableHead>Followers</TableHead>}
                {activeTab === 'google' && <TableHead>Website</TableHead>}
                {activeTab === 'facebook' && <TableHead>Page Type</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {leads.map((lead, idx) => (
                <TableRow
                  key={`${lead.name||""}-${lead.phone||""}` || idx}
                  className={clsx(
                    idx % 2 === 1 ? 'bg-zinc-50 dark:bg-zinc-900' : '',
                    'hover:bg-blue-50 dark:hover:bg-zinc-800 group transition-colors cursor-pointer'
                  )}
                >
                  <TableCell>{lead.name}</TableCell>
                  <TableCell>{lead.phone || <span className="text-gray-400">—</span>}</TableCell>
                  <TableCell>{lead.email || <span className="text-gray-400">—</span>}</TableCell>
                  <TableCell>{lead.instagram || <span className="text-gray-400">—</span>}</TableCell>
                  {activeTab === 'instagram' && <TableCell>{lead.followers !== undefined ? lead.followers.toLocaleString() : <span className="text-gray-400">—</span>}</TableCell>}
                  {activeTab === 'google' && <TableCell>{lead.website ? <a href={`https://${lead.website}`} className="text-blue-700 underline group-hover:underline" target="_blank" rel="noopener noreferrer">{lead.website}</a> : <span className="text-gray-400">—</span>}</TableCell>}
                  {activeTab === 'facebook' && <TableCell>{lead.pageType || <span className="text-gray-400">—</span>}</TableCell>}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
        {loading && (
          <div className="flex flex-col items-center gap-2 my-8">
            <svg className="animate-spin h-8 w-8 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>
            <span className="text-blue-600">Searching for leads…</span>
          </div>
        )}
        {leads.length === 0 && !loading && <div className="text-gray-600">No leads found yet. Enter region and niche above, then click "Find Leads".</div>}
        {error && <div className="mb-2 text-sm text-red-600 dark:text-red-400">{error}</div>}
      </div>
    </div>
  );
}

export default App;

// --- Export utility functions ---
const exportToCSV = () => {
  if (!leads.length) return;
  const header = ["Name", "Phone", "Email", "Instagram"];
  const rows = leads.map(l => [l.name, l.phone || "", l.email || "", l.instagram || ""]);
  const csvContent = [header, ...rows]
    .map(r => r.map(f => `"${String(f).replace(/"/g, '""')}"`).join(","))
    .join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  saveAs(blob, `leads_${activeTab}_${region || "all"}_${niche || "all"}.csv`);
};

const exportToExcel = () => {
  if (!leads.length) return;
  const ws = XLSX.utils.json_to_sheet(
    leads.map(l => ({
      Name: l.name,
      Phone: l.phone || "",
      Email: l.email || "",
      Instagram: l.instagram || ""
    }))
  );
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Leads");
  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([wbout], { type: "application/octet-stream" });
  saveAs(blob, `leads_${activeTab}_${region || "all"}_${niche || "all"}.xlsx`);
};

function getTabMessage() {
  switch (activeTab) {
    case 'instagram':
      return 'Instagram handle search is simulated for demo purposes. Real integration possible with valid Business API access.';
    case 'google':
      return 'Google Business lead search is simulated for demo, designed for extension with real Google Places or Custom Search API.';
    case 'facebook':
      return 'Facebook business search is simulated for demo. Real results require official API integration.';
    default:
      return '';
  }
}

// --- Export utility functions ---
const exportToCSV = () => {
  if (!leads.length) return;
  const header = ["Name", "Phone", "Email", "Instagram"];
  const rows = leads.map(l => [l.name, l.phone || "", l.email || "", l.instagram || ""]);
  const csvContent = [header, ...rows]
    .map(r => r.map(f => `"${String(f).replace(/"/g, '""')}"`).join(","))
    .join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  saveAs(blob, `leads_${activeTab}_${region || "all"}_${niche || "all"}.csv`);
};

const exportToExcel = () => {
  if (!leads.length) return;
  const ws = XLSX.utils.json_to_sheet(
    leads.map(l => ({
      Name: l.name,
      Phone: l.phone || "",
      Email: l.email || "",
      Instagram: l.instagram || ""
    }))
  );
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Leads");
  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([wbout], { type: "application/octet-stream" });
  saveAs(blob, `leads_${activeTab}_${region || "all"}_${niche || "all"}.xlsx`);
};

function getTabMessage() {
  switch (activeTab) {
    case 'instagram':
      return 'Instagram handle search is simulated for demo purposes. Real integration possible with valid Business API access.';
    case 'google':
      return 'Google Business lead search is simulated for demo, designed for extension with real Google Places or Custom Search API.';
    case 'facebook':
      return 'Facebook business search is simulated for demo. Real results require official API integration.';
    default:
      return '';
  }
}
